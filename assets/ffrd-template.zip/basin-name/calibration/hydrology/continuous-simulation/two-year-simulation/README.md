# two-year-simulation

ffrd directory structure. see parent directory for description of intended use
